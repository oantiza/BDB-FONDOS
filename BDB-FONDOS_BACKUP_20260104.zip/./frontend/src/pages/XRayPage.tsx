import { useState, useMemo } from 'react' // Ensure useMemo
import { useXRayAnalytics } from '../hooks/useXRayAnalytics'
import { usePortfolioStats } from '../hooks/usePortfolioStats'
import DiversificationDonut from '../components/charts/DiversificationDonut'

import MetricCard from '../components/common/MetricCard'
import SimpleStyleBox from '../components/charts/SimpleStyleBox'
import ComparativeFundHistoryChart from '../components/charts/ComparativeFundHistoryChart'

import { Fund, PortfolioItem } from '../types'

interface XRayPageProps {
    portfolio: PortfolioItem[];
    fundDatabase: Fund[];
    totalCapital: number;
    onBack: () => void;
}

export default function XRayPage({ portfolio, fundDatabase, totalCapital, onBack }: XRayPageProps) {
    // ... (rest of file until table) ...
    <tr className="border-t border-black">
        <td className="py-6 pl-4 text-xl font-[550] text-[#2C3E50] tracking-tight">TOTAL CARTERA</td>
        <td className="py-6 text-right font-[550] text-[#2C3E50] text-xl tabular-nums">100.00%</td>
        <td className="py-6 text-right font-[550] text-[#2C3E50] text-xl tabular-nums">
            {totalCapital.toLocaleString('es-ES', { style: 'currency', currency: 'EUR' })}
        </td>
        {/* EMPTY VOLATILITY CELL AS REQUESTED */}
        <td className="py-6 pr-4"></td>
    </tr>
    // ... existing state

    // Custom Hooks
    const { metrics, loading, errorMsg } = useXRayAnalytics({ portfolio, fundDatabase });
    const { categoryAllocation, sortedHoldings, styleStats } = usePortfolioStats({ portfolio, metrics });

    return (
        <div className="h-screen flex flex-col bg-white font-sans text-slate-700 overflow-hidden">
            {/* MINIMALIST HEADER (Simplified to match Main Dashboard) */}
            <div className="h-16 bg-gradient-to-r from-[#003399] to-[#0055CC] text-white flex items-center justify-between px-6 z-20 shrink-0 border-b border-white/10 shadow-md">
                <div className="flex items-center gap-4">
                    <button
                        onClick={onBack}
                        className="text-white/70 hover:text-white transition-colors flex items-center gap-1 text-xs uppercase tracking-widest font-bold"
                    >
                        ← Volver
                    </button>
                    <div className="h-4 w-px bg-white/20 mx-2"></div>
                    <span className="font-light text-xl tracking-tight leading-none">Análisis de <span className="font-bold">Cartera</span></span>

                    {/* ANALYTICS TAB */}

                    <a
                        href="/x-ray/analytics"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="ml-4 text-white/70 hover:text-[#D4AF37] transition-colors text-xs font-bold uppercase tracking-widest flex items-center gap-1 group bg-white/5 px-3 py-1 rounded-full border border-white/10 hover:border-white/30"
                    >
                        Gráficos Avanzados <span className="group-hover:translate-x-0.5 transition-transform">↗</span>
                    </a>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto bg-white p-12 scrollbar-thin">
                {loading ? (
                    <div className="flex flex-col items-center justify-center h-full opacity-50">
                        <p className="text-xs font-bold text-[#95a5a6] uppercase tracking-widest animate-pulse">Calculando...</p>
                    </div>
                ) : errorMsg ? (
                    <div className="text-center py-20 text-[#95a5a6]">
                        <span className="text-4xl block mb-2">⚠️</span>
                        {errorMsg}
                        <div className="mt-4">
                            <button onClick={onBack} className="text-[#2C3E50] underline text-sm">Volver al Dashboard</button>
                        </div>
                    </div>
                ) : !metrics ? (
                    <div className="text-center py-20 text-[#95a5a6]">
                        Error en el cálculo o sin datos
                    </div>
                ) : (
                    <div className="max-w-[1200px] mx-auto space-y-12 pb-20">

                        {/* SECTION 1: EDITORIAL TABLE (Moved to Top) */}
                        <div>
                            <div className="mb-6 flex justify-between items-end">
                                <h1 className="text-[#2C3E50] text-3xl font-light tracking-tight">Composición de la Cartera</h1>
                            </div>
                            <table className="w-full text-left border-collapse">
                                <thead>
                                    <tr className="border-b border-black h-10">
                                        <th className="py-2 pl-4 text-[#A07147] text-base uppercase tracking-[0.2em] font-bold w-[40%]">Fondo / Estrategia</th>
                                        <th className="py-2 text-[#A07147] text-base uppercase tracking-[0.2em] font-bold text-right">Peso</th>
                                        <th className="py-2 text-[#A07147] text-base uppercase tracking-[0.2em] font-bold text-right">Capital</th>
                                        <th className="py-2 pr-4 text-[#A07147] text-base uppercase tracking-[0.2em] font-bold text-right">RIESGO</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {[...portfolio].sort((a, b) => b.weight - a.weight).map((fund, index, arr) => {
                                        const isFirst = index === 0;
                                        const isLast = index === arr.length - 1;

                                        return (
                                            <tr key={fund.isin} className="last:border-0 hover:bg-[#fcfcfc] transition-colors group">
                                                <td className={`pr-8 pl-4 align-top ${isFirst ? 'pt-8 pb-4' : isLast ? 'pt-4 pb-8' : 'py-4'}`}>
                                                    <div className="text-[#2C3E50] font-[450] text-base leading-tight mb-1">
                                                        {fund.name}
                                                    </div>
                                                    <div className="text-[#A07147] text-[10px] uppercase tracking-widest font-medium">
                                                        {fund.std_extra?.category || fund.std_type || 'General'}
                                                    </div>
                                                </td>
                                                <td className={`align-top text-right text-[#2C3E50] font-[450] text-base tabular-nums ${isFirst ? 'pt-8 pb-4' : isLast ? 'pt-4 pb-8' : 'py-4'}`}>
                                                    {fund.weight.toFixed(2)}%
                                                </td>
                                                <td className={`align-top text-right text-[#2C3E50] font-[450] text-base tabular-nums ${isFirst ? 'pt-8 pb-4' : isLast ? 'pt-4 pb-8' : 'py-4'}`}>
                                                    {((fund.weight / 100) * totalCapital).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' })}
                                                </td>
                                                <td className={`align-top text-right pr-4 text-[#2C3E50] font-[450] text-sm tabular-nums ${isFirst ? 'pt-8 pb-4' : isLast ? 'pt-4 pb-8' : 'py-4'}`}>
                                                    {(metrics.assets?.[fund.isin]?.volatility !== undefined)
                                                        ? (metrics.assets[fund.isin].volatility * 100).toFixed(2) + '%'
                                                        : (fund.std_perf?.volatility !== undefined)
                                                            ? (fund.std_perf.volatility * 100).toFixed(2) + '%'
                                                            : '-'}
                                                </td>
                                            </tr>
                                        );
                                    })}

                                    <tr className="border-t border-black">
                                        <td className="py-6 pl-4 text-xl font-[550] text-[#2C3E50] tracking-tight">TOTAL CARTERA</td>
                                        <td className="py-6 text-right font-[550] text-[#2C3E50] text-xl tabular-nums">100.00%</td>
                                        <td className="py-6 text-right font-[550] text-[#2C3E50] text-xl tabular-nums">
                                            {totalCapital.toLocaleString('es-ES', { style: 'currency', currency: 'EUR' })}
                                        </td>
                                        <td className="py-6 pr-4"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        {/* SECTION 2: METRICS GRID (Moved Below) */}
                        <div>
                            <div className="mb-6 border-t border-[#eeeeee] pt-12">
                                <h2 className="text-[#2C3E50] text-3xl font-light tracking-tight">Métricas de Cartera</h2>
                            </div>
                            <div className="grid grid-cols-2 lg:grid-cols-6 gap-8 pb-4">
                                <MetricCard label="Rentabilidad (CAGR)" value={metrics.metrics?.cagr ? (metrics.metrics.cagr * 100).toFixed(2) + "%" : "-"} color="text-[#2C3E50]" />
                                <MetricCard label="Volatilidad" value={metrics.metrics?.volatility ? (metrics.metrics.volatility * 100).toFixed(2) + "%" : "-"} color="text-[#2C3E50]" />
                                <MetricCard label="Ratio Sharpe" value={metrics.metrics?.sharpe?.toFixed(2) || "-"} color="text-[#2C3E50]" />
                                <MetricCard label="Max Drawdown" value={metrics.metrics?.maxDrawdown ? (metrics.metrics.maxDrawdown * 100).toFixed(2) + "%" : "-"} color="text-[#C0392B]" />
                                <MetricCard label="Tasa Libre Riesgo" value={metrics.metrics?.rf_rate ? (metrics.metrics.rf_rate * 100).toFixed(2) + "%" : "-"} color="text-[#7f8c8d]" />
                                <MetricCard label="Diversificación" value={metrics.metrics?.diversificationScore?.toFixed(2) || "-"} color="text-[#2C3E50]" />
                            </div>
                        </div>

                        {/* SECTION 2b: TOP 10 HOLDINGS & DIVERSIFICATION (Side-by-Side 1/3 - 2/3) */}
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-y-16 lg:gap-x-0 border-t border-[#eeeeee] pt-12">

                            {/* LEFT COL: Top 10 Holdings */}
                            {sortedHoldings && sortedHoldings.length > 0 && (
                                <div className="lg:pr-12 lg:col-span-1">
                                    <div className="flex items-center gap-4 mb-6">
                                        <h3 className="text-[#2C3E50] text-3xl font-light tracking-tight">10 Principales Posiciones</h3>
                                    </div>

                                    <table className="w-full text-left border-collapse">
                                        <thead>
                                            <tr className="border-b border-black h-10">
                                                <th className="py-2 text-[#A07147] text-base uppercase tracking-[0.2em] font-bold w-[75%]">Activo / Sector</th>
                                                <th className="py-2 text-[#A07147] text-base uppercase tracking-[0.2em] font-bold text-right">Peso</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {sortedHoldings.map((holding: any, idx: number) => (
                                                <tr key={idx} className="last:border-0 hover:bg-[#fcfcfc] transition-colors group">
                                                    <td className="py-3 pr-8 align-top">
                                                        <div className="text-[#2C3E50] font-normal text-sm leading-tight mb-1">
                                                            {holding.name || holding.isin}
                                                        </div>
                                                        <div className="text-[#A07147] text-[10px] uppercase tracking-widest font-medium">
                                                            {holding.sector || holding.std_type || 'General'}
                                                        </div>
                                                    </td>
                                                    <td className="py-3 align-top text-right text-[#2C3E50] font-[450] text-sm tabular-nums">
                                                        {holding.weight.toFixed(2)}%
                                                    </td>
                                                </tr>
                                            ))}
                                            {/* THICK TOTALS ROW FOR TOP 10 */}
                                            <tr className="border-t border-black">
                                                <td className="py-4 text-sm font-[550] text-[#2C3E50] tracking-tight text-right w-full pr-4">TOP 10 TOTAL</td>
                                                <td className="py-4 text-right font-[550] text-[#2C3E50] text-base tabular-nums">
                                                    {sortedHoldings.reduce((acc: number, h: any) => acc + h.weight, 0).toFixed(2)}%
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            )}

                            {/* RIGHT COL: Diversification Chart & Style Boxes */}
                            <div className="h-full flex flex-col px-8 lg:pl-12 lg:border-l lg:border-[#eeeeee] lg:col-span-2">
                                {/* Stack Container: Donut (Top) | StyleBoxes (Bottom) */}
                                <div className="flex flex-col w-full h-full">
                                    {/* Donut Chart - Top */}
                                    {/* Title - Fixed at Top */}
                                    <div className="flex items-center gap-4 mb-2 justify-center shrink-0">
                                        <h3 className="text-[#2C3E50] text-3xl font-light tracking-tight">Diversificación</h3>
                                        <span className="text-[#A07147] text-[10px] uppercase tracking-[0.2em] font-bold">Por Categorías</span>
                                    </div>

                                    {/* Content Container - Pushed Down */}
                                    <div className="w-full flex-col justify-center flex-1 mt-24">
                                        <div className="w-full h-[240px] flex items-center justify-center relative z-0">
                                            <DiversificationDonut assets={categoryAllocation} />
                                        </div>
                                    </div>

                                    {/* Style Boxes - Bottom (Horizontal Row) */}
                                    <div className="flex gap-12 items-center justify-center border-t border-slate-100 pt-4 mt-4 shrink-0 pb-2">
                                        <SimpleStyleBox type="equity" vertical={styleStats.equity.cap} horizontal={styleStats.equity.style} />
                                        <SimpleStyleBox type="fixed-income" vertical={styleStats.fi.credit === 'High' ? 'High' : styleStats.fi.credit === 'Low' ? 'Low' : 'Med'} horizontal={styleStats.fi.duration} />
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* SECTION 3: COMPARATIVE HISTORY CHART */}
                        <div className="border-t border-[#eeeeee] pt-12 mt-12 mb-12">
                            <ComparativeFundHistoryChart
                                funds={fundDatabase.filter(f => portfolio.some(p => p.isin === f.isin))}
                            />
                        </div>
                    </div>
                )}
            </div>
        </div >
    )
}


